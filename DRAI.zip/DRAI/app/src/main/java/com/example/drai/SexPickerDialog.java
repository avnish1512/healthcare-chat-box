package com.example.drai;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class SexPickerDialog extends DialogFragment {
    public interface OnSexSetListener { void onSexSet(String sex); }
    private OnSexSetListener listener;
    private String selectedSex = "";
    public void setOnSexSetListener(OnSexSetListener listener) { this.listener = listener; }
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_sex_picker, container, false);
        TextView maleOption = view.findViewById(R.id.maleOption);
        TextView femaleOption = view.findViewById(R.id.femaleOption);
        TextView preferNotToSayOption = view.findViewById(R.id.preferNotToSayOption);
        maleOption.setOnClickListener(v -> { selectedSex = getString(R.string.sex_male); updateSelection(maleOption, femaleOption, preferNotToSayOption); });
        femaleOption.setOnClickListener(v -> { selectedSex = getString(R.string.sex_female); updateSelection(femaleOption, maleOption, preferNotToSayOption); });
        preferNotToSayOption.setOnClickListener(v -> { selectedSex = getString(R.string.sex_prefer_not_to_say); updateSelection(preferNotToSayOption, maleOption, femaleOption); });
        view.findViewById(R.id.saveChangesButton).setOnClickListener(v -> {
            if (listener != null && !selectedSex.isEmpty()) listener.onSexSet(selectedSex);
            dismiss();
        });
        view.findViewById(R.id.closeDialogButton).setOnClickListener(v -> dismiss());
        return view;
    }
    private void updateSelection(TextView selectedView, TextView... otherViews) {
        selectedView.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        selectedView.setTextColor(getResources().getColor(android.R.color.white));
        for (TextView view : otherViews) {
            view.setBackgroundColor(getResources().getColor(android.R.color.transparent));
            view.setTextColor(getResources().getColor(android.R.color.black));
        }
    }
}