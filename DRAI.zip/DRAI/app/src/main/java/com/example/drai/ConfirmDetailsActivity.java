package com.example.drai;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ConfirmDetailsActivity extends AppCompatActivity implements BirthdatePickerDialog.OnDateSetListener, SexPickerDialog.OnSexSetListener {
    private TextView birthdateTextView, sexTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_details);
        birthdateTextView = findViewById(R.id.birthdateTextView);
        sexTextView = findViewById(R.id.sexTextView);
        findViewById(R.id.birthdateRow).setOnClickListener(v -> {
            BirthdatePickerDialog dialog = new BirthdatePickerDialog();
            dialog.setOnDateSetListener(this);
            dialog.show(getSupportFragmentManager(), "BirthdatePickerDialog");
        });
        findViewById(R.id.sexRow).setOnClickListener(v -> {
            SexPickerDialog dialog = new SexPickerDialog();
            dialog.setOnSexSetListener(this);
            dialog.show(getSupportFragmentManager(), "SexPickerDialog");
        });
        findViewById(R.id.finishButton).setOnClickListener(v -> {
            Intent intent = new Intent(ConfirmDetailsActivity.this, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
    @Override
    public void onDateSet(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy", Locale.US);
        birthdateTextView.setText(sdf.format(calendar.getTime()));
        birthdateTextView.setTextColor(getResources().getColor(android.R.color.black));
    }
    @Override
    public void onSexSet(String sex) {
        sexTextView.setText(sex);
        sexTextView.setTextColor(getResources().getColor(android.R.color.black));
    }
}