package com.example.drai;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView chatRecyclerView;
    private EditText messageEditText;
    private ImageButton sendButton;
    private MessageAdapter messageAdapter;
    private List<Message> messageList;
    private final String GEMINI_API_KEY = "AIzaSyCHGQsdveYqurFncCrFj58f7KaHbEXGKpM";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        TextView titleTextView = findViewById(R.id.chatTitleTextView);
        setColoredTitle(titleTextView, "Hey! I'm DR.AI", "DR.AI", "#4A90E2");
        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(messageAdapter);
        addMessage("Hello! How can I help you today?", false);
        sendButton.setOnClickListener(v -> sendMessage());
        messageEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });
        setupBottomNavigation();
    }
    private void sendMessage() {
        String userMessage = messageEditText.getText().toString().trim();
        if (!userMessage.isEmpty()) {
            addMessage(userMessage, true);
            messageEditText.setText("");
            callGeminiApi(userMessage);
        }
    }
    private void addMessage(String text, boolean isUser) {
        messageList.add(new Message(text, isUser));
        messageAdapter.notifyItemInserted(messageList.size() - 1);
        chatRecyclerView.scrollToPosition(messageList.size() - 1);
    }
    private void callGeminiApi(String userPrompt) {
        addMessage("Typing...", false);
        new Thread(() -> {
            try {
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + GEMINI_API_KEY);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                JSONObject content = new JSONObject();
                content.put("text", userPrompt);
                JSONArray parts = new JSONArray();
                parts.put(content);
                JSONObject contents = new JSONObject();
                contents.put("parts", parts);
                JSONArray contentsArray = new JSONArray();
                contentsArray.put(contents);
                JSONObject requestBody = new JSONObject();
                requestBody.put("contents", contentsArray);
                con.setDoOutput(true);
                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = requestBody.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                }
                JSONObject jsonResponse = new JSONObject(response.toString());
                String botResponse = jsonResponse.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                runOnUiThread(() -> {
                    messageList.remove(messageList.size() - 1);
                    messageAdapter.notifyItemRemoved(messageList.size());
                    addMessage(botResponse, false);
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    messageList.remove(messageList.size() - 1);
                    messageAdapter.notifyItemRemoved(messageList.size());
                    addMessage("Sorry, I'm having trouble connecting.", false);
                });
            }
        }).start();
    }
    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_chat);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_today) {
                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (itemId == R.id.nav_chat) {
                return true;
            } else if (itemId == R.id.nav_me) {
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return false;
        });
    }
    private void setColoredTitle(TextView textView, String fullText, String coloredText, String colorHex) {
        SpannableString spannableString = new SpannableString(fullText);
        int startIndex = fullText.indexOf(coloredText);
        if (startIndex != -1) {
            spannableString.setSpan(new ForegroundColorSpan(Color.parseColor(colorHex)), startIndex, startIndex + coloredText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            textView.setText(spannableString);
        } else {
            textView.setText(fullText);
        }
    }
}