// Path: app/src/main/java/com/example/drai/OtherOptionsActivity.java

package com.example.drai;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

/**
 * This screen provides multiple sign-up methods, including social logins
 * and the primary email/password flow.
 */
public class OtherOptionsActivity extends AppCompatActivity {

    private EditText emailEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_options);

        emailEditText = findViewById(R.id.emailEditText);

        // Handle the back button press.
        findViewById(R.id.backArrowImageView).setOnClickListener(v -> finish());

        // Handle the email sign-up button press.
        findViewById(R.id.signUpButton).setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();

            // Validate the email format.
            if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                return;
            }

            // Pass the validated email to the password creation screen.
            Intent intent = new Intent(OtherOptionsActivity.this, CreatePasswordActivity.class);
            intent.putExtra("EMAIL", email);
            startActivity(intent);
        });
    }
}
