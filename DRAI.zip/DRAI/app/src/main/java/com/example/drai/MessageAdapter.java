// Path: app/src/main/java/com/example/drai/MessageAdapter.java

package com.example.drai;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * Adapter for the RecyclerView in the chat screen. It handles displaying
 * different layouts for user messages and bot messages.
 */
public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    // View type constants to differentiate between user and bot messages.
    private static final int VIEW_TYPE_USER = 1;
    private static final int VIEW_TYPE_BOT = 2;

    private List<Message> messageList;

    public MessageAdapter(List<Message> messageList) {
        this.messageList = messageList;
    }

    /**
     * This method is called by the RecyclerView to determine which layout to use
     * for a specific item in the list.
     * @param position The position of the item in the list.
     * @return The view type (either VIEW_TYPE_USER or VIEW_TYPE_BOT).
     */
    @Override
    public int getItemViewType(int position) {
        // Return a different view type based on who sent the message.
        if (messageList.get(position).isUser()) {
            return VIEW_TYPE_USER;
        } else {
            return VIEW_TYPE_BOT;
        }
    }

    /**
     * This method is called when the RecyclerView needs a new ViewHolder.
     * It inflates the correct layout based on the viewType.
     */
    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        // Inflate the correct layout based on the view type returned from getItemViewType.
        if (viewType == VIEW_TYPE_USER) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_user, parent, false);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_bot, parent, false);
        }
        return new MessageViewHolder(view);
    }

    /**
     * This method is called to display the data at a specific position.
     * It gets the message object and sets its text in the TextView.
     */
    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        Message message = messageList.get(position);
        holder.messageTextView.setText(message.getText());
    }

    /**
     * Returns the total number of items in the list.
     */
    @Override
    public int getItemCount() {
        return messageList.size();
    }

    /**
     * ViewHolder class to hold the views for a single message item.
     * This improves performance by avoiding repeated calls to findViewById.
     */
    static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageTextView;

        MessageViewHolder(@NonNull View itemView) {
            super(itemView);
            messageTextView = itemView.findViewById(R.id.messageTextView);
        }
    }
}
