package com.example.drai;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignUpActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mAuth = FirebaseAuth.getInstance();
        TextView titleTextView = findViewById(R.id.titleTextView);
        Button otherOptionsButton = findViewById(R.id.otherOptionsButton);
        titleTextView.setText(Html.fromHtml(getString(R.string.start_journey_title), Html.FROM_HTML_MODE_LEGACY));
        otherOptionsButton.setOnClickListener(v -> startActivity(new Intent(SignUpActivity.this, OtherOptionsActivity.class)));
    }
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            startActivity(new Intent(SignUpActivity.this, HomeActivity.class));
            finish();
        }
    }
}