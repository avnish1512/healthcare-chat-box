package com.example.drai;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import java.util.Calendar;

public class BirthdatePickerDialog extends DialogFragment {
    public interface OnDateSetListener { void onDateSet(int year, int month, int day); }
    private OnDateSetListener listener;
    public void setOnDateSetListener(OnDateSetListener listener) { this.listener = listener; }
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_birthdate_picker, container, false);
        NumberPicker monthPicker = view.findViewById(R.id.monthPicker);
        NumberPicker dayPicker = view.findViewById(R.id.dayPicker);
        NumberPicker yearPicker = view.findViewById(R.id.yearPicker);
        monthPicker.setMinValue(0);
        monthPicker.setMaxValue(11);
        monthPicker.setDisplayedValues(new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"});
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        yearPicker.setMinValue(currentYear - 100);
        yearPicker.setMaxValue(currentYear);
        yearPicker.setValue(currentYear - 25);
        dayPicker.setMinValue(1);
        dayPicker.setMaxValue(31);
        view.findViewById(R.id.saveChangesButton).setOnClickListener(v -> {
            if (listener != null) listener.onDateSet(yearPicker.getValue(), monthPicker.getValue(), dayPicker.getValue());
            dismiss();
        });
        view.findViewById(R.id.closeDialogButton).setOnClickListener(v -> dismiss());
        return view;
    }
}