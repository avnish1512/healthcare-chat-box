package com.example.drai;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;

/**
 * This screen allows the user to create a password for their new account.
 * It uses Firebase Authentication to create the user.
 */
public class CreatePasswordActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText passwordEditText;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_password);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        passwordEditText = findViewById(R.id.passwordEditText);

        // Get the email passed from the previous activity.
        email = getIntent().getStringExtra("EMAIL");
        if (email == null) {
            Toast.makeText(this, "Error: Email not provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        findViewById(R.id.backArrowImageView).setOnClickListener(v -> finish());
        findViewById(R.id.nextButton).setOnClickListener(v -> createAccount());
    }

    /**
     * Creates a new user account using the provided email and password
     * with Firebase Authentication.
     */
    private void createAccount() {
        String password = passwordEditText.getText().toString().trim();

        // Simple password validation.
        if (password.length() < 8) {
            Toast.makeText(this, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create user with email and password.
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Sign up success, navigate to the next step.
                        Toast.makeText(CreatePasswordActivity.this, "Account Created.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(CreatePasswordActivity.this, ConfirmDetailsActivity.class);
                        startActivity(intent);
                        // Finish all previous registration activities.
                        finishAffinity();
                    } else {
                        // If sign up fails, display a message to the user.
                        Toast.makeText(CreatePasswordActivity.this, "Authentication failed: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }
}
