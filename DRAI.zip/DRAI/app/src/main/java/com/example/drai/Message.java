// Path: app/src/main/java/com/example/drai/Message.java

package com.example.drai;

/**
 * A simple model class (POJO) to represent a single chat message.
 */
public class Message {
    private String text;
    private boolean isUser; // Differentiates between user messages and bot messages

    public Message(String text, boolean isUser) {
        this.text = text;
        this.isUser = isUser;
    }

    public String getText() {
        return text;
    }

    public boolean isUser() {
        return isUser;
    }
}
